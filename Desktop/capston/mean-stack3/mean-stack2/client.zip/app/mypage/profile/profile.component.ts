import { Component, OnInit } from '@angular/core';
import { AuthService, UserService } from '../../shared/services';
import { ToastComponent } from '../../shared/toast/toast.component';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';




@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  
  user = {};
  isLoading = true;

  //importance: number;
  importance= 
    {department: '', location: ''}
  ;

  constructor(private auth: AuthService,
              public toast: ToastComponent,
              private userService: UserService) { }

  ngOnInit() {
    this.getUser();
  }

  getUser() {
    this.userService.getUser(this.auth.currentUser).subscribe(
      data => this.user = data,
      error => console.log(error),
      () => this.isLoading = false
    );
  }

  save(user) {
    console.log(this.importance);
    this.auth.currentUser.preference = this.importance;
    this.userService.editUser(user).subscribe(
      res => this.toast.setMessage('account settings saved!', 'success'),
      error => console.log(error),
      () => {
        this.auth.setCurrentUser(user);

      }
    );
    console.log(user);
  }


}
