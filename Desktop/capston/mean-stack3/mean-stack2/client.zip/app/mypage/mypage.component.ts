import { AuthService } from './../shared/services/auth.service';
import { Component, OnInit } from '@angular/core';




@Component({
  selector: 'app-mypage',
  templateUrl: './mypage.component.html',
  styleUrls: ['./mypage.component.css']
})
export class MypageComponent implements OnInit {

  ngOnInit(){

  }
}
